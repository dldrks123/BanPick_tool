<!-- frontend/src/App.vue -->
<template>
  <router-view />
</template>

<script setup lang="ts">
// 아무것도 없거나 전역 레이아웃이 필요하면 여기에 추가
</script>

<style>
/* 전역 스타일 */
</style>
